### Installation Instructions

To install the required dependencies for this package, use the following command:

``` sh
pip install -r requirements.txt
pip install metapub python-dotenv openai tiktoken langchain langchain_openai langchain_core langchain_community langchain_text_splitters XlsxWriter
```
